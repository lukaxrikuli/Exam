//
//  BrandViewController.swift
//  Exam
//
//  Created by luka xrikuli on 27.12.21.
//

/*import UIKit

class BrandViewController: UIViewController {
    var cars = [Car]()
    

    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    @IBAction func PriceLowToHigh(_ sender: UIButton) {
    }
    @IBAction func PriceHighToLow(_ sender: UIButton) {
    }
    

}

extension BrandViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cars.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
     
}
 }*/
