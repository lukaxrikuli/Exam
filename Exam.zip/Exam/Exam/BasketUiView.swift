//
//  BasketUiView.swift
//  Exam
//
//  Created by luka xrikuli on 28.12.21.
//

import UIKit

class BasketUiView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
